# 8bit border-image

A Pen created on CodePen.io. Original URL: [https://codepen.io/enbee81/pen/wvdMJGp](https://codepen.io/enbee81/pen/wvdMJGp).

